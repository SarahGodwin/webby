# Webby 

###If you got a link to this repository, download the zip file, and open the index.html file please.  
Thanks!
Sarah

# What am I
Otherwise, this is a repository for finished (or mostly finished) web work.
```
<html>

</html>
```
```
css
javascript
jquery


```

### Installing

I'm using a mac, and typically open with chrome or firefox. 

```
Did you know a firefox is a Red Panda?
```


```
My hope is to meet a firefox in person/animal
```



## Contributing
If you wish to contribute, please use comments or link to something so I can learn. 

## Versioning

Since this is a solo project, my versioning is likely flawed.  I am not even using branches other than to play with GitHub.

## Authors

Sarah Godwin

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details

```
i might have deleted the license. oops
```

## Acknowledgments

* My family
